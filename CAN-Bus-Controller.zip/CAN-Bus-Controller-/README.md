# CAN-Bus-Controller
An CAN bus Controller implemented in Verilog




#!/bin/sh
rm -rf work
mkdir work

echo "Compiling CAN Simulation Core"
ncvlog -nocopyright -work work ../../../CAN_BUS_Model.v

echo "Compiling CAN Example Design"
ncvlog -nocopyright -work work ../../example_design/CAN_BUS_Model_top.v

echo "Compiling Test Bench"
ncvlog -nocopyright -work work ../can_v3_2_tb.v

ncelab -nocopyright -access +r work.can_v3_2_tb glbl

ncsim -nocopyright -gui work.can_v3_2_tb -input "@simvision -input wave.sv"
